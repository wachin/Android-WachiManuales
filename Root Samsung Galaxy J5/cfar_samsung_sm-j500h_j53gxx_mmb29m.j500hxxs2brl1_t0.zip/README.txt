-----------------------
      CF-Auto-Root
 https://firmware.mobi
(c) 2012-2017 Chainfire
-----------------------

!!! USE AT YOUR OWN RISK !!!

!!! YOUR WARRANTY IS NOW VOID !!!

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

------------------------------------------------------------------------------

Your device must have:
- An unlocked bootloader
- OEM unlock enabled (if present) in developer options
- Factory reset protection (if present) disabled

... and this package must be generated for the same device and a very similar
firmware.

If any of these requirements are not met, flashing is likely to fail, your
data may be lost, and your device may fail to boot.

In case of issues, re-flashing the full stock firmware will usually resolve
any problems (aside from data loss). But be advise that there is always a
small chance your device may suffer an unrecoverable hard-brick.

If your device boot-loops even after re-flashing the full stock firmware,
go into recovery mode and perform a data erase / factory reset. On newer
devices this is needed after a firmware re-flash.

!!! If you are currently not rooted, or you are rooted but your device's !!!
!!! storage is encrypted, YOUR DATA MAY BE WIPED !!!

------------------------------------------------------------------------------

If you are not absolutely sure you want to continue, press Ctrl+C now
to abort.

------------------------------------------------------------------------------

To flash the CF-Auto-Root package, press any key to continue, and in the
screen that comes up, press the AP button and find the "image.tar.md5" file
in the "image" subdirectory of this package.

Put your device in download mode ( adb reboot download, or power it off and
hold volume down + home + power to turn it on again , followed by volume up
to continue ) and connect it via USB cable.

On your computer's screen, the textbox should now show "Added!!". Press the
"Start" button to start flashing, and wait approximately 15 minutes for
Android to boot back up.

The device may reboot several times in the process.

If your computer cannot communicate with the device (the "Start" button
doesn't do anything, flashing fails, etc), please try another USB port
(closing the Odin3 program in the meantime) and rebooting your computer.
If you still cannot get it to work, please seek assistance on the forums of
XDA-Developers.com
